# ####### UI
# DO NOT delete the next line by hand
# last change date:
# valid colors:
# red, yellow, aqua, blue, light-blue, green, navy, teal, olive, lime, orange, fuchsia, purple, maroon, black

sps_app$ui
