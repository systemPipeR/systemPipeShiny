# systemPipeShiny App Root

1. In this folder you should have your UI, server and global files.
2. `www` folder is for internet resources like images, js, css files
3. `R` folder contains all SPS tab files, your plotting functions and other help R functions. When the app starts, it will automatically source all `.R` or `.r` files inside this folder.
