# SPS config file directory

- a tab information file
- a defualt option file 
- a database file 
