# DT snap

    <div id="" style="width:100%; height:auto; " class="datatables html-widget html-widget-output"></div>

