### Not in Use

# ## UI
# core_rightUI <- function(id){
#     ns <- NS(id)
#     uiOutput(ns("right_bar"))
# }
#
# ## server
# core_rightServer <- function(id, shared){
#     module <- function(input, output, session){
#         ns <- session$ns
#     }
#     moduleServer(id, module)
# }
#
#
